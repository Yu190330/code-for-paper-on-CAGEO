
THREE.NodeLoader = function () {};

THREE.NodeLoader.prototype = {

    constructor: THREE.NodeLoader,

    addEventListener: THREE.EventDispatcher.prototype.addEventListener,
    hasEventListener: THREE.EventDispatcher.prototype.hasEventListener,
    removeEventListener: THREE.EventDispatcher.prototype.removeEventListener,
    dispatchEvent: THREE.EventDispatcher.prototype.dispatchEvent,

    load: function ( url, callback ) {

        var scope = this;
        var request = new XMLHttpRequest();

        request.addEventListener( 'load', function ( event ) {

            var geometry = scope.parse( event.target.responseText );

            scope.dispatchEvent( { type: 'load', content: geometry } );

            if ( callback ) callback( geometry );
        

        }, false );

        request.addEventListener( 'progress', function ( event ) {

            scope.dispatchEvent( { type: 'progress', loaded: event.loaded, total: event.total } );

        }, false );

        request.addEventListener( 'error', function () {

            scope.dispatchEvent( { type: 'error', message: 'Couldn\'t load URL [' + url + ']' } );

        }, false );

        request.open( 'GET', url, true );
        request.send( null );


    },

    parse: function ( data ) {

        var geometry = new THREE.Geometry();

        function vertex( x, y, z ) {

            geometry.vertices.push( new THREE.Vector3( x, y, z ) );

        }

        function face3( a, b, c ) {

            geometry.faces.push( new THREE.Face3( a, b, c ) );

        }

        function face4( a, b, c, d ) {

            geometry.faces.push( new THREE.Face4( a, b, c, d ) );

        }
        var material_marker = new Array();
        //材质
        function mtl(a){
            geometry.material_marker.push(a);
        }

        var pattern, result;

        // node-int float float float
        // pattern = /([\s*]+[\d*])([\s*]+[(-?)\d*\.\d*]+)([\s*]+[(-?)\d*\.\d*]+)([\s*]+[(-?)\d*\.\d*]+)/g;
        // pattern =/V[ ]+([\d]+)[ ]+([\+|\-]?[\d]+[\.]?[\d|\-|e]+)[ ]+([\+|\-]?[\d]+[\.]?[\d|\-|e]+)[ ]+([\+|\-]?[\d]+[\.]?[\d|\-|e]+)/g;
        pattern =     /V([\s]+[\d]+[\s+])( +[\d|\.?|\+|\-|e|E]+ )( +[\d|\.?|\+|\-|e|E]+ )( +[\d|\.?|\+|\-|e|E]+)/g
        while ( ( result = pattern.exec( data ) ) != null ) {

            // node int float float float

            vertex( parseFloat( result[ 2 ] -12597), parseFloat( result[ 3 ] -164316), parseFloat( result[ 4 ]-1.12) );

        }
        // face-int int int int int

        // pattern = /([\s*]+[\d*])([\s*]+[\d*])([\s*]+[\d*])([\s*]+[\d*])([\s*]+[\d*])/g;
        pattern = /F[ ]+([\d]+)[ ]+([\d]+)[ ]+([\d]+)[ ]+([\d]+)[ ]+([\-]?[\d]?[\d])/g;

        while ( ( result = pattern.exec( data ) ) != null ) {

            // int int int int int  面索引 顶点索引 顶点索引 顶点索引 地层编号

            face3( parseInt( result[ 2 ]-1 ), parseInt( result[ 3 ]-1 ), parseInt( result[ 4 ]-1 ) );
            mtl(parseInt( result[5]));

        }

        // // 4 int int int int

        // pattern = /4[ ]+([\d]+)[ ]+([\d]+)[ ]+([\d]+)[ ]+([\d]+)/g;

        // while ( ( result = pattern.exec( data ) ) != null ) {

        //     // ["4 1 2 3 4", "1", "2", "3", "4"]

        //     face4( parseInt( result[ 1 ] ), parseInt( result[ 2 ] ), parseInt( result[ 3 ] ), parseInt( result[ 4 ] ) );

        // }
        // //从node文件中获取vertex坐标
        // //int int int int -node文件头
        // var nodeheader_pattern=/[\d*]+([\s*]+[\d*])([\s*]+[\d*])([\s*]+[\d*])/;
        // //int float float float -node文件内容
        // var vertex_pattern=/([\s*]+[\d*])([\s*]+[(-?)\d*\.\d*]+)([\s*]+[(-?)\d*\.\d*]+)([\s*]+[(-?)\d*\.\d*]+)/;
        // //从face文件中获取face索引
        // //int int 
        // var faceheader_pattern=/([\d*])([\s*]+[\d*])/;
        // //int int int int int
        // var face_pattern=/([\s*]+[\d*])([\s*]+[\d*])([\s*]+[\d*])([\s*]+[\d*])([\s*]+[\d*])/;


        // geometry.computeCentroids();
        geometry.computeFaceNormals();
        geometry.computeVertexNormals();
        geometry.computeBoundingSphere();
        // geometry.translate(0,0,0);\
        // console.log(vertex.length);
        return geometry;
    }

}; 